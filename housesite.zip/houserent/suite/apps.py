from django.apps import AppConfig


class SuiteConfig(AppConfig):
    name = 'suite'
