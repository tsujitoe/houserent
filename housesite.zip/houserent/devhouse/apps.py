from django.apps import AppConfig


class DevhouseConfig(AppConfig):
	name = 'devhouse'
    